function validateForm(){
    var textz = document.getElementById("textarea");

    if (textz == ""){
        alert("Frequently asked question must be filled out!")
        return false;
    }
    else{
        document.getElementById("submitButton").addEventListener("click",function(){

        }){
            console.log("Your Frequently asked question has been sent and processed! We will Post the answer ASAP.");
        }
    }
}